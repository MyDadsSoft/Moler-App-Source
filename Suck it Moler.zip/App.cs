using System.Windows;
using Dark.Net;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Add Dark.Net theme logic here
        DarkNet.Instance.SetCurrentProcessTheme(Theme.Auto);

        // Any other startup logic...
    }
}
