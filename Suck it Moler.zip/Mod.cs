using System.ComponentModel;

public class Mod : INotifyPropertyChanged
{
	private bool _isDownloaded;

	public bool IsDownloaded
	{
		get
		{
			return _isDownloaded;
		}
		set
		{
			if (_isDownloaded != value)
			{
				_isDownloaded = value;
				OnPropertyChanged("IsDownloaded");
			}
		}
	}

	public event PropertyChangedEventHandler PropertyChanged;

	protected void OnPropertyChanged(string propName)
	{
		this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
	}
}
