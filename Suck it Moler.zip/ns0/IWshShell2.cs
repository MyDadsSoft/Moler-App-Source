using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ns0;

[ComImport]
[CompilerGenerated]
[Guid("24BE5A30-EDFE-11D2-B933-00104B365C9F")]
[TypeIdentifier]
public interface IWshShell2 : IWshShell
{
}
