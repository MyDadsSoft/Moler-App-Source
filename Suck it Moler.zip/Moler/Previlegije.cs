using System.Diagnostics;
using System.Security.Principal;
using System.Windows;

namespace Moler;

public static class Previlegije
{
	public static bool IsRunningAsAdmin()
	{
		return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
	}

	public static void RestartAsAdmin()
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = Process.GetCurrentProcess().MainModule.FileName,
				UseShellExecute = true,
				Verb = "runas"
			});
		}
		catch
		{
			MessageBox.Show("The application does not have administrator privileges!\n\nIf the files are not updated or other problems occur, first try to run the application as an administrator. If you have problems again, ask for help on Discord!", "Moler - V1.0.0.0");
		}
		Application.Current.Shutdown();
	}
}
