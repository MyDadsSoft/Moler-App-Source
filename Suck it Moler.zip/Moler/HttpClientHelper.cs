using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Moler;

public static class HttpClientHelper
{
	private static readonly HttpClient client = new HttpClient();

	public static async Task<List<Mod>> GetModsAsync(string category = null, int? vipOnly = null, string sortBy = "newest", string version = "All")
	{
		List<string> list = new List<string>();
		if (!string.IsNullOrEmpty(category))
		{
			list.Add("category=" + Uri.EscapeDataString(category));
		}
		if (vipOnly.HasValue)
		{
			list.Add("vipOnly=" + vipOnly.Value);
		}
		if (!string.IsNullOrEmpty(version) && !version.Equals("All", StringComparison.OrdinalIgnoreCase))
		{
			list.Add("version=" + Uri.EscapeDataString(version));
		}
		list.Add("sortBy=" + Uri.EscapeDataString(sortBy));
		string text = "https://molerapi.moler.cloud/mods/?" + string.Join("&", list);
		HttpResponseMessage obj = await client.GetAsync(text);
		obj.EnsureSuccessStatusCode();
		string json = await obj.Content.ReadAsStringAsync();
		JsonSerializerOptions options = new JsonSerializerOptions
		{
			PropertyNameCaseInsensitive = true
		};
		List<Mod> list2 = new List<Mod>();
		using JsonDocument jsonDocument = JsonDocument.Parse(json);
		foreach (JsonElement item in jsonDocument.RootElement.EnumerateArray())
		{
			JsonElement value;
			bool num = item.TryGetProperty("link", out value);
			string text2 = (num ? value.GetString() : null);
			if (!num || text2 == null || text2.IndexOf("molerap.moler.cloud", StringComparison.OrdinalIgnoreCase) < 0)
			{
				Mod mod = JsonSerializer.Deserialize<Mod>(item.GetRawText(), options);
				if (mod != null)
				{
					list2.Add(mod);
				}
			}
		}
		return list2;
	}

	public static async Task<bool> UpdateDownloadsAsync(int modId)
	{
		string text = $"https://molerapi.moler.cloud/mods/{modId}/updateDownloads";
		StringContent val = new StringContent("{}", Encoding.UTF8, "application/json");
		return (await client.PostAsync(text, (HttpContent)(object)val)).IsSuccessStatusCode;
	}
}
