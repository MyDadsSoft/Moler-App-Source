using System.Management;

namespace Moler
{
    public static class HWIDsystem
    {
        public static string GetCpuId()
        {
            return "BYPASSED-CPU";
        }

        public static string GetMotherboardId()
        {
            return "BYPASSED-MOBO";
        }

        public static string GetGpuId()
        {
            return "BYPASSED-GPU";
        }

        public static string GetHWID()
        {
            return "BYPASSED-HWID";
        }
    }
}
