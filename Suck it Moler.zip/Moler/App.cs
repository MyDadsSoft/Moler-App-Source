using System.Windows;

namespace Moler;

public partial class App : Application
{
}
