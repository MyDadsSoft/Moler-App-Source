using DiscordRPC;
using DiscordRPC.Logging;

namespace Moler;

public class DiscordPlay
{
	private DiscordRpcClient _client;

	public void Initialize()
	{
		_client = new DiscordRpcClient("1369745511883477084")
		{
			Logger = new ConsoleLogger
			{
				Level = LogLevel.Warning
			}
		};
		_client.Initialize();
		_client.SetPresence(new RichPresence
		{
			Details = "Browsing Mods",
			State = "",
			Timestamps = Timestamps.Now,
			Assets = new Assets
			{
				LargeImageKey = "large_image",
				LargeImageText = "Moler - V2.0.0.0"
			},
			Buttons = new Button[1]
			{
				new Button
				{
					Label = "Join our Discord",
					Url = "https://discord.gg/5UmesUeSGv"
				}
			}
		});
	}

	public void Shutdown()
	{
		_client?.Dispose();
	}
}
