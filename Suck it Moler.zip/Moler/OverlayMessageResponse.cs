namespace Moler;

public class OverlayMessageResponse
{
	public bool show { get; set; }

	public string message { get; set; }
}
