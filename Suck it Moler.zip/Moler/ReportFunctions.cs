using System;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using Newtonsoft.Json;

namespace Moler;

public static class ReportFunctions
{
	private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;

	private static readonly HttpClient client = new HttpClient();

	[DllImport("dwmapi.dll")]
	private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

	public static void ShowReportDialog(Mod mod, string Username)
	{
		Window reportWindow = new Window
		{
			Title = "Report a Problem",
			Width = 400.0,
			Height = 450.0,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			ResizeMode = ResizeMode.NoResize,
			Owner = Application.Current.MainWindow,
			Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#000005"),
			Foreground = Brushes.White,
			FontFamily = new FontFamily("Quantico")
		};
		reportWindow.SourceInitialized += delegate
		{
			IntPtr handle = new WindowInteropHelper(reportWindow).Handle;
			int attrValue = 1;
			DwmSetWindowAttribute(handle, 20, ref attrValue, 4);
		};
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(20.0),
			Orientation = Orientation.Vertical
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Reporting as: " + Username,
			FontWeight = FontWeights.Bold,
			FontSize = 14.0,
			Margin = new Thickness(0.0, 0.0, 0.0, 10.0),
			Foreground = Brushes.White
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = "⚠\ufe0f False or troll reports will result in a ban.\n✍\ufe0f Please write in English only.",
			Foreground = Brushes.OrangeRed,
			FontWeight = FontWeights.Bold,
			FontSize = 13.0,
			Margin = new Thickness(0.0, 0.0, 0.0, 15.0),
			TextWrapping = TextWrapping.Wrap
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Select the issue you're experiencing:",
			FontWeight = FontWeights.Bold,
			FontSize = 19.0,
			Margin = new Thickness(0.0, 0.0, 0.0, 10.0),
			Foreground = Brushes.White
		});
		ComboBox issueComboBox = new ComboBox
		{
			Style = (Application.Current.FindResource("NoHoverComboBoxStyle") as Style),
			Margin = new Thickness(0.0, 0.0, 0.0, 10.0),
			FontSize = 14.0,
			Height = 30.0
		};
		string[] array = new string[6] { "Mod is outdated", "Wrong category", "Download is broken or expired", "Mod is a duplicate / reposted", "Mod misleads users (fake description / images)", "Other" };
		foreach (string content in array)
		{
			ComboBoxItem newItem = new ComboBoxItem
			{
				Content = content,
				Style = (Application.Current.FindResource("ModernComboBoxItemStyle") as Style)
			};
			issueComboBox.Items.Add(newItem);
		}
		stackPanel.Children.Add(issueComboBox);
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Additional details:",
			Margin = new Thickness(0.0, 20.0, 0.0, 5.0),
			Foreground = Brushes.White
		});
		TextBox txtCustom = new TextBox
		{
			Height = 70.0,
			AcceptsReturn = true,
			TextWrapping = TextWrapping.Wrap,
			BorderBrush = new SolidColorBrush(Color.FromRgb(60, 60, 60))
		};
		txtCustom.Style = Application.Current.FindResource("AdditionalDetailsBoxStyle") as Style;
		stackPanel.Children.Add(txtCustom);
		CheckBox confirmCheck = new CheckBox
		{
			Content = "I confirm this report is valid.",
			Foreground = Brushes.White,
			Margin = new Thickness(0.0, 15.0, 0.0, 0.0)
		};
		confirmCheck.Style = Application.Current.FindResource("CheckBoxHoverStyle") as Style;
		stackPanel.Children.Add(confirmCheck);
		Button button = new Button
		{
			Content = "Submit Report",
			HorizontalAlignment = HorizontalAlignment.Stretch,
			Height = 40.0,
			Margin = new Thickness(0.0, 20.0, 0.0, 0.0),
			Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#012C4C"),
			Foreground = Brushes.Black,
			FontWeight = FontWeights.Bold,
			BorderThickness = new Thickness(0.0),
			Padding = new Thickness(10.0),
			IsEnabled = true
		};
		button.Style = Application.Current.FindResource("ButtonHoverStyle") as Style;
		button.Click += async delegate
		{
			if (issueComboBox.SelectedItem == null)
			{
				MessageBox.Show("⚠\ufe0f Please select an issue you're experiencing.", "Input Required", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return;
			}
			if (string.IsNullOrWhiteSpace(txtCustom.Text))
			{
				MessageBox.Show("⚠\ufe0f Additional details required.", "Input Required", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return;
			}
			if (confirmCheck.IsChecked != true)
			{
				MessageBox.Show("⚠\ufe0f Please confirm that this report is valid.", "Input Required", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return;
			}
			ComboBoxItem obj = issueComboBox.SelectedItem as ComboBoxItem;
			object obj2;
			if (obj != null)
			{
				object content3 = obj.Content;
				if (content3 != null)
				{
					obj2 = content3.ToString();
					if (obj2 != null)
					{
						goto IL_00c2;
					}
				}
			}
			obj2 = "(No issue selected)";
			goto IL_00c2;
			IL_00c2:
			string issue = (string)obj2;
			string text = txtCustom.Text;
			var value = new
			{
				username = Username,
				modId = mod.ModId,
				modName = mod.Name,
				issue = issue,
				details = text
			};
			try
			{
				StringContent val = new StringContent(JsonConvert.SerializeObject(value), Encoding.UTF8, "application/json");
				if ((await client.PostAsync("https://molerapi.moler.cloud/api/reports", (HttpContent)(object)val)).IsSuccessStatusCode)
				{
					MessageBox.Show("✅ Report successfully submitted!", "Report Sent", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					MessageBox.Show("❌ Error submitting report. Please try again later.", "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("❌ Exception occurred:\n" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			reportWindow.Close();
		};
		stackPanel.Children.Add(button);
		ScrollViewer content2 = new ScrollViewer
		{
			Content = stackPanel,
			VerticalScrollBarVisibility = ScrollBarVisibility.Hidden
		};
		reportWindow.Content = content2;
		reportWindow.ShowDialog();
	}
}
