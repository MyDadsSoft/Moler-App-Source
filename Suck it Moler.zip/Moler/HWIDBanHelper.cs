using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Moler
{
    public static class HWIDBanHelper
    {
        public class BanInfo
        {
            public string BanId { get; set; }
            public string Username { get; set; }
            public string BannedBy { get; set; }
            public string Reason { get; set; }
            public DateTime BannedUntil { get; set; }
            public DateTime BannedAt { get; set; }
            public string BanAppealLink { get; set; }
            public string BuyUnbanLink { get; set; }
        }

        public static async Task<bool> CheckHWIDBan(string hwid)
        {
            // Bypass logic – always return false (not banned)
            return false;
        }

        public static async Task<BanInfo> GetBanInfo(string hwid)
        {
            // Bypass logic – no ban info
            return null;
        }

        public static async Task UpdateUserHWID(string discordId, string hwid)
        {
            // Do nothing
        }
    }
}
