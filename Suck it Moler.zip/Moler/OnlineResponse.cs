namespace Moler;

public class OnlineResponse
{
	public int online { get; set; }
}
