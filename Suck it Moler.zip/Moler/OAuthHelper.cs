using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;

namespace Moler;

public static class OAuthHelper
{
	public static async Task<string> GetDiscordToken(string code)
	{
		HttpClient client = new HttpClient();
		try
		{
			string requestUri = "https://molerapi.moler.cloud/auth/discord/exchange";
			var value = new { code };
			HttpResponseMessage response;
			try
			{
				response = await client.PostAsJsonAsync(requestUri, value);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri slanju zahtjeva:\n" + ex.Message);
				return null;
			}
			if (response.IsSuccessStatusCode)
			{
				using JsonDocument jsonDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
				if (jsonDocument.RootElement.TryGetProperty("access_token", out var value2))
				{
					return value2.GetString();
				}
				MessageBox.Show("Exchange uspio, ali nije bilo access_token u odgovoru.");
				return null;
			}
			string text = await response.Content.ReadAsStringAsync();
			MessageBox.Show("Token exchange failed:\n" + $"Status: {response.StatusCode}\n" + "Body: " + text);
			return null;
		}
		finally
		{
			((IDisposable)client)?.Dispose();
		}
	}

	public static async Task<DiscordUser> GetDiscordUserInfo(string token)
	{
		HttpClient client = new HttpClient();
		try
		{
			client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
			HttpResponseMessage val;
			try
			{
				val = await client.GetAsync("https://discord.com/api/users/@me");
			}
			catch (Exception ex)
			{
				MessageBox.Show("Greška pri dohvaćanju user info:\n" + ex.Message);
				return null;
			}
			if (!val.IsSuccessStatusCode)
			{
				MessageBox.Show($"UserInfo failed: {val.StatusCode}");
				return null;
			}
			return JsonSerializer.Deserialize<DiscordUser>(await val.Content.ReadAsStringAsync());
		}
		finally
		{
			((IDisposable)client)?.Dispose();
		}
	}
}
