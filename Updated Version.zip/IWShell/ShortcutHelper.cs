using System;
using System.IO;
using System.Windows.Forms;
using ns0;

namespace IWShell;

public static class ShortcutHelper
{
	public static void CreateShortcutIfNeeded()
	{
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "Moler.lnk");
		string executablePath = Application.ExecutablePath;
		if (!File.Exists(text))
		{
			CreateShortcut(executablePath, text);
		}
	}

	private static void CreateShortcut(string targetPath, string shortcutPath)
	{
		try
		{
			if (File.Exists(shortcutPath))
			{
				File.Delete(shortcutPath);
			}
			WshShell wshShell = (WshShell)Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
			IWshShortcut wshShortcut = (IWshShortcut)(dynamic)wshShell.CreateShortcut(shortcutPath);
			wshShortcut.TargetPath = targetPath;
			wshShortcut.WorkingDirectory = Path.GetDirectoryName(targetPath);
			wshShortcut.Description = "Moler";
			string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "images\\appikonica.ico");
			if (File.Exists(text))
			{
				wshShortcut.IconLocation = text;
			}
			wshShortcut.Save();
		}
		catch (Exception ex)
		{
			Console.WriteLine("Greška pri kreiranju shortcut-a: " + ex.Message);
		}
	}
}
