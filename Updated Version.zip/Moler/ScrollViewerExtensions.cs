using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace Moler;

public static class ScrollViewerExtensions
{
	public static readonly DependencyProperty AnimatedVerticalOffsetProperty = DependencyProperty.RegisterAttached("AnimatedVerticalOffset", typeof(double), typeof(ScrollViewerExtensions), new PropertyMetadata(0.0, OnAnimatedVerticalOffsetChanged));

	private static void OnAnimatedVerticalOffsetChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
	{
		if (d is ScrollViewer scrollViewer)
		{
			scrollViewer.ScrollToVerticalOffset((double)e.NewValue);
		}
	}

	public static void SetAnimatedVerticalOffset(DependencyObject element, double value)
	{
		element.SetValue(AnimatedVerticalOffsetProperty, value);
	}

	public static double GetAnimatedVerticalOffset(DependencyObject element)
	{
		return (double)element.GetValue(AnimatedVerticalOffsetProperty);
	}

	public static void SmoothScrollTo(this ScrollViewer scrollViewer, double toOffset, TimeSpan duration)
	{
		SetAnimatedVerticalOffset(scrollViewer, scrollViewer.VerticalOffset);
		DoubleAnimation animation = new DoubleAnimation
		{
			From = scrollViewer.VerticalOffset,
			To = toOffset,
			Duration = new Duration(duration),
			EasingFunction = new QuadraticEase
			{
				EasingMode = EasingMode.EaseOut
			}
		};
		scrollViewer.BeginAnimation(AnimatedVerticalOffsetProperty, animation);
	}
}
