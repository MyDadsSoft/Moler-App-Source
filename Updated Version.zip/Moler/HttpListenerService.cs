using System;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Moler;

public static class HttpListenerService
{
	private static HttpListener listener;

	public static async Task StartListener()
	{
		listener = new HttpListener();
		listener.Prefixes.Add("http://localhost:4002/");
		try
		{
			listener.Start();
		}
		catch (Exception ex)
		{
			MessageBox.Show("Failed to start HttpListener: " + ex.Message);
			return;
		}
		while (listener.IsListening)
		{
			try
			{
				ProcessRequest(await listener.GetContextAsync());
			}
			catch (Exception)
			{
			}
		}
	}

	private static async void ProcessRequest(HttpListenerContext context)
	{
		HttpListenerRequest request = context.Request;
		HttpListenerResponse response = context.Response;
		if (request.Url.AbsolutePath.Equals("/auth/discord/callback", StringComparison.OrdinalIgnoreCase))
		{
			string code = request.QueryString["code"];
			string text = "Authorized User";
			if (!string.IsNullOrEmpty(code))
			{
				text = await (await Application.Current.Dispatcher.InvokeAsync(async delegate
				{
					if (!(Application.Current.MainWindow is MainWindow mainWindow))
					{
						return "Authorized User";
					}
					await mainWindow.HandleDiscordCallback(code);
					return mainWindow.DiscordName.Text;
				}));
			}
			string s = "\r\n<html>\r\n  <head>\r\n    <meta charset='UTF-8'>\r\n    <title>Authorized</title>\r\n    <link href='https://fonts.googleapis.com/css2?family=Quantico&display=swap' rel='stylesheet'>\r\n    <style>\r\n      body {\r\n        background-color: #000005;\r\n        color: #29f1b7;\r\n        font-family: 'Quantico', sans-serif;\r\n        font-size: 20px;\r\n        text-align: center;\r\n        padding-top: 20%;\r\n        text-shadow: 0 0 10px #29f1b7;\r\n      }\r\n    </style>\r\n  </head>\r\n  <body>\r\n    Welcome, " + text + "! You may close this window.\r\n  </body>\r\n</html>";
			byte[] bytes = Encoding.UTF8.GetBytes(s);
			response.ContentLength64 = bytes.Length;
			response.ContentType = "text/html";
			await response.OutputStream.WriteAsync(bytes, 0, bytes.Length);
		}
		else
		{
			response.StatusCode = 404;
		}
		response.OutputStream.Close();
	}
}
