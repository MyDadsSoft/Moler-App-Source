using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;

namespace Moler;

public static class HWIDBanHelper
{
	public class BanInfo
	{
		public string BanId { get; set; }

		public string Username { get; set; }

		public string BannedBy { get; set; }

		public string Reason { get; set; }

		public DateTime BannedUntil { get; set; }

		public DateTime BannedAt { get; set; }

		public string BanAppealLink { get; set; }

		public string BuyUnbanLink { get; set; }
	}

	public class BanCheckResult
	{
		public bool banned { get; set; }

		public string message { get; set; }
	}

	public static async Task<bool> CheckHWIDBan(string hwid)
	{
		try
		{
			HttpClient client = new HttpClient();
			try
			{
				StringContent val = new StringContent(JsonSerializer.Serialize(new { hwid }), Encoding.UTF8, "application/json");
				HttpResponseMessage val2 = await client.PostAsync("https://molerapi.moler.cloud/users/checkBan", (HttpContent)(object)val);
				if (!val2.IsSuccessStatusCode)
				{
					return false;
				}
				return JsonSerializer.Deserialize<BanCheckResult>(await val2.Content.ReadAsStringAsync())?.banned ?? false;
			}
			finally
			{
				((IDisposable)client)?.Dispose();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("Error checking HWID ban: " + ex.Message);
			return false;
		}
	}

	public static async Task<BanInfo> GetBanInfo(string hwid)
	{
		HttpClient client = new HttpClient();
		try
		{
			StringContent val = new StringContent("{\"hwid\": \"" + hwid + "\"}", Encoding.UTF8, "application/json");
			HttpResponseMessage obj = await client.PostAsync("https://molerapi.moler.cloud/users/checkBan", (HttpContent)(object)val);
			if (!obj.IsSuccessStatusCode)
			{
				throw new Exception("Neuspješan zahtjev prema ban API-ju.");
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(await obj.Content.ReadAsStringAsync());
			JsonElement rootElement = jsonDocument.RootElement;
			if (rootElement.TryGetProperty("banned", out var value) && value.GetBoolean())
			{
				if (!rootElement.TryGetProperty("banInfo", out var value2))
				{
					return null;
				}
				return new BanInfo
				{
					BanId = value2.GetProperty("ban_id").GetString(),
					Username = value2.GetProperty("username").GetString(),
					BannedBy = value2.GetProperty("banned_by").GetString(),
					Reason = value2.GetProperty("reason").GetString(),
					BannedAt = DateTime.Parse(value2.GetProperty("banned_at").GetString()),
					BannedUntil = DateTime.Parse(value2.GetProperty("banned_until").GetString()),
					BanAppealLink = value2.GetProperty("ban_appeal_link").GetString(),
					BuyUnbanLink = value2.GetProperty("buy_unban_link").GetString()
				};
			}
			return null;
		}
		finally
		{
			((IDisposable)client)?.Dispose();
		}
	}

	public static async Task UpdateUserHWID(string discordId, string hwid)
	{
		try
		{
			HttpClient client = new HttpClient();
			try
			{
				StringContent val = new StringContent(JsonSerializer.Serialize(new
				{
					discord_id = discordId,
					hwid = hwid
				}), Encoding.UTF8, "application/json");
				if (!(await client.PostAsync("https://molerapi.moler.cloud/users/updateHWID", (HttpContent)(object)val)).IsSuccessStatusCode)
				{
					MessageBox.Show("Greška pri ažuriranju HWID-a!");
				}
			}
			finally
			{
				((IDisposable)client)?.Dispose();
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("Izuzetak prilikom update-a HWID-a: " + ex.Message);
		}
	}
}
