using System;
using System.Text.Json.Serialization;

namespace Moler;

public class Mod
{
	[JsonPropertyName("id")]
	public int Id { get; set; }

	[JsonPropertyName("mod_id")]
	public string ModId { get; set; }

	[JsonPropertyName("name")]
	public string Name { get; set; }

	[JsonPropertyName("category")]
	public string Category { get; set; }

	[JsonPropertyName("download_link")]
	public string DownloadLink { get; set; }

	[JsonPropertyName("vip_only")]
	public int VipOnly { get; set; }

	[JsonPropertyName("image_url")]
	public string ImageUrl { get; set; }

	[JsonPropertyName("created_at")]
	public DateTime CreatedAt { get; set; }

	[JsonPropertyName("version")]
	public string Version { get; set; }

	[JsonPropertyName("downloads")]
	public int Downloads { get; set; }

	[JsonPropertyName("leaked_by")]
	public string LeakedBy { get; set; }

	public bool IsNew => (DateTime.UtcNow - CreatedAt).TotalDays <= 7.0;

	public bool IsDownloaded { get; set; }

	public string LocalFilePath { get; set; }

	public override string ToString()
	{
		return Name;
	}
}
