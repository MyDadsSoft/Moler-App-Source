using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Security.Authentication;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using IWShell;
using Moler.Properties;
using Newtonsoft.Json;

namespace Moler;

public partial class MainWindow : Window, IComponentConnector, IStyleConnector
{
	public static class ScrollViewerBehavior
	{
		public static readonly DependencyProperty VerticalOffsetProperty = DependencyProperty.RegisterAttached("VerticalOffset", typeof(double), typeof(ScrollViewerBehavior), new PropertyMetadata(0.0, OnVerticalOffsetChanged));

		public static void SetVerticalOffset(DependencyObject element, double value)
		{
			element.SetValue(VerticalOffsetProperty, value);
		}

		public static double GetVerticalOffset(DependencyObject element)
		{
			return (double)element.GetValue(VerticalOffsetProperty);
		}

		private static void OnVerticalOffsetChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			if (d is ScrollViewer scrollViewer)
			{
				scrollViewer.ScrollToVerticalOffset((double)e.NewValue);
			}
		}
	}

	private string _currentDownloadFilePath;

	private CancellationTokenSource _downloadCancellationTokenSource;

	private Mod _currentlyDownloadingMod;

	private ManualResetEventSlim _pauseDownloadEvent = new ManualResetEventSlim(initialState: true);

	private bool _showFavoritesOnly;

	private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;

	private string _downloadPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

	private string _searchQuery = "";

	private readonly HttpClient _httpClient = new HttpClient();

	private DiscordPlay _discordPlay = new DiscordPlay();

	private System.Timers.Timer _refreshTimer;

	private const string BaseUrl = "https://molerapi.moler.cloud/";

	public async Task HandleDiscordCallback(string code)
	{
		if (string.IsNullOrEmpty(code))
		{
			System.Windows.MessageBox.Show("Nema validnog koda!");
			return;
		}
		try
		{
			string text = await OAuthHelper.GetDiscordToken(code);
			if (string.IsNullOrEmpty(text))
			{
				System.Windows.MessageBox.Show("Ne možemo dobiti token!");
				return;
			}
			DiscordUser userInfo = await OAuthHelper.GetDiscordUserInfo(text);
			if (userInfo != null)
			{
				string hwid = HWIDsystem.GetHWID();
				await HWIDBanHelper.UpdateUserHWID(userInfo.id, hwid);
				if (await HWIDBanHelper.CheckHWIDBan(hwid))
				{
					HWIDBanHelper.BanInfo banInfo = await HWIDBanHelper.GetBanInfo(hwid);
					if (banInfo != null)
					{
						string text2 = "ACCESS TO THE MOLER APPLICATION IS FORBIDDEN TO YOU, REASON:\n\n⚓ You are banned ⚓\n\n\ud83d\udd12 Ban ID: " + banInfo.BanId + "\n\ud83d\udc64 Username: " + banInfo.Username + "\n\ud83d\udee1\ufe0f Banned by: " + banInfo.BannedBy + "\n\ud83d\udcc4 Reason: " + banInfo.Reason + "\n" + $"\ud83d\udcc6 Banned at: {banInfo.BannedAt}\n" + $"⏳ Banned until: {banInfo.BannedUntil}\n\n" + "\ud83d\udce9 Appeal: " + banInfo.BanAppealLink + "\n\ud83d\udcb0 Buy Unban: " + banInfo.BuyUnbanLink;
						BanOverlayMessage.Text = text2;
						BanOverlay.Visibility = Visibility.Visible;
						return;
					}
				}
				DiscordName.Text = userInfo.username;
				BtnLogin.Content = "Logout";
				Overlay.Visibility = Visibility.Hidden;
				EnableUI();
				SaveUserSettings();
				await LoadMods();
			}
			else
			{
				System.Windows.MessageBox.Show("Nema korisničkih podataka!");
			}
		}
		catch (Exception ex)
		{
			System.Windows.MessageBox.Show("Došlo je do pogreške: " + ex.Message);
		}
	}

	private async Task CheckBanStatusIfLoggedIn()
	{
		if (!(BtnLogin.Content.ToString() == "Logout"))
		{
			return;
		}
		string hwid = HWIDsystem.GetHWID();
		if (await HWIDBanHelper.CheckHWIDBan(hwid))
		{
			HWIDBanHelper.BanInfo banInfo = await HWIDBanHelper.GetBanInfo(hwid);
			if (banInfo != null)
			{
				string text = "ACCESS TO THE MOLER APPLICATION IS DISABLED FOR YOU, REASON:\n\n⚓ You are banned ⚓\n\n\ud83d\udd12 Ban ID: " + banInfo.BanId + "\n\ud83d\udc64 Username: " + banInfo.Username + "\n\ud83d\udee1\ufe0f Banned by: " + banInfo.BannedBy + "\n\ud83d\udcc4 Reason: " + banInfo.Reason + "\n" + $"\ud83d\udcc6 Banned at: {banInfo.BannedAt}\n" + $"⏳ Banned until: {banInfo.BannedUntil}\n\n" + "\ud83d\udce9 Appeal: " + banInfo.BanAppealLink + "\n\ud83d\udcb0 Buy Unban: " + banInfo.BuyUnbanLink;
				BanOverlayMessage.Text = text;
				BanOverlay.Visibility = Visibility.Visible;
			}
		}
	}

	private async void ApplyButton_Click(object sender, RoutedEventArgs e)
	{
		await LoadMods();
	}

	private async Task LoadMods()
	{
		try
		{
			string category = (CategoryComboBox_Filter.SelectedItem as ComboBoxItem)?.Content.ToString();
			int? vipOnly = null;
			if (VIPFreeComboBox_Filter.SelectedItem is ComboBoxItem comboBoxItem)
			{
				string text = comboBoxItem.Content.ToString();
				if (text == "VIP")
				{
					vipOnly = 1;
				}
				else if (text == "Free")
				{
					vipOnly = 0;
				}
			}
			string sortBy = "newest";
			if (SortComboBox_Filter.SelectedItem is ComboBoxItem comboBoxItem2)
			{
				sortBy = comboBoxItem2.Content.ToString() switch
				{
					"Most Popular" => "downloads", 
					"Oldest First" => "oldest", 
					"Newest First" => "newest", 
					_ => "newest", 
				};
			}
			string text2 = (VersionComboBox_Filter.SelectedItem as ComboBoxItem)?.Content.ToString();
			if (string.IsNullOrEmpty(text2))
			{
				text2 = "All";
			}
			List<Mod> list;
			if (_showFavoritesOnly)
			{
				string favorites = Settings.Default.Favorites;
				List<string> favoritesList = new List<string>();
				if (!string.IsNullOrEmpty(favorites))
				{
					favoritesList = favorites.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
				}
				list = (await HttpClientHelper.GetModsAsync()).Where((Mod mod) => favoritesList.Contains(mod.ModId.ToString())).ToList();
			}
			else
			{
				list = await HttpClientHelper.GetModsAsync(category, vipOnly, sortBy, text2);
			}
			ModsListBox.ItemsSource = list;
			foreach (Mod item in list)
			{
				bool isDownloaded = Directory.GetFiles(_downloadPath, item.Name + ".*").Any();
				item.IsDownloaded = isDownloaded;
			}
		}
		catch (Exception ex)
		{
			System.Windows.MessageBox.Show("Error loading mods: " + ex.Message);
		}
	}

	private async Task LoadModsWithFilters(string category, int? vipOnly, string sortBy, string version)
	{
		try
		{
			List<Mod> list;
			if (_showFavoritesOnly)
			{
				string favorites = Settings.Default.Favorites;
				List<string> favoritesList = new List<string>();
				if (!string.IsNullOrEmpty(favorites))
				{
					favoritesList = favorites.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
				}
				list = (await HttpClientHelper.GetModsAsync()).Where((Mod mod) => favoritesList.Contains(mod.ModId.ToString())).ToList();
			}
			else
			{
				list = await HttpClientHelper.GetModsAsync(category, vipOnly, sortBy, version);
			}
			if (!string.IsNullOrEmpty(version) && version.ToLower() != "all")
			{
				list = list.Where((Mod mod) => mod.Version.Equals(version, StringComparison.OrdinalIgnoreCase)).ToList();
			}
			ModsListBox.ItemsSource = list;
			foreach (Mod item in list)
			{
				bool isDownloaded = Directory.GetFiles(_downloadPath, item.Name + ".*").Any();
				item.IsDownloaded = isDownloaded;
			}
		}
		catch (Exception ex)
		{
			System.Windows.MessageBox.Show("Error loading mods: " + ex.Message);
		}
	}

	private async void FavoritesToggleButton_Click(object sender, RoutedEventArgs e)
	{
		_showFavoritesOnly = !_showFavoritesOnly;
		FavoritesToggleButton.Content = (_showFavoritesOnly ? "Show All" : "Show Saved");
		await LoadMods();
	}

	private async void DownloadButton_Click(object sender, RoutedEventArgs e)
	{
		if (!(sender is System.Windows.Controls.Button { Tag: var tag }) || !(tag is Mod mod))
		{
			return;
		}
		if (_downloadCancellationTokenSource != null)
		{
			if (_currentlyDownloadingMod != null && _currentlyDownloadingMod.Id == mod.Id)
			{
				System.Windows.MessageBox.Show("This mod is already downloading");
			}
			else
			{
				System.Windows.MessageBox.Show("Cannot download two mods at the same time");
			}
			return;
		}
		_currentlyDownloadingMod = mod;
		_downloadCancellationTokenSource = new CancellationTokenSource();
		_pauseDownloadEvent.Set();
		PauseButton.IsEnabled = true;
		ContinueButton.IsEnabled = false;
		NotificationPanel.Visibility = Visibility.Visible;
		NotificationTitle.Text = "Downloading: " + mod.Name;
		NotificationDetails.Text = "0 MB / 0 MB";
		DownloadProgressBar.Value = 0.0;
		try
		{
			if (!Uri.IsWellFormedUriString(mod.DownloadLink, UriKind.Absolute))
			{
				throw new InvalidOperationException("Neispravan URL: " + mod.DownloadLink);
			}
			HttpClientHandler val = new HttpClientHandler
			{
				AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate),
				SslProtocols = SslProtocols.Tls12
			};
			val.ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
			HttpClient httpClient = new HttpClient((HttpMessageHandler)(object)val)
			{
				Timeout = TimeSpan.FromMinutes(5.0)
			};
			try
			{
				httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("MolerApp/1.0");
				HttpResponseMessage response = await httpClient.GetAsync(mod.DownloadLink, (HttpCompletionOption)1, _downloadCancellationTokenSource.Token);
				try
				{
					response.EnsureSuccessStatusCode();
					long totalBytes = response.Content.Headers.ContentLength ?? (-1L);
					bool canReportProgress = totalBytes != -1L;
					double totalMB = (double)totalBytes / 1024.0 / 1024.0;
					string text = null;
					ContentDispositionHeaderValue contentDisposition = response.Content.Headers.ContentDisposition;
					if (contentDisposition != null)
					{
						if (!string.IsNullOrEmpty(contentDisposition.FileNameStar))
						{
							text = contentDisposition.FileNameStar.Trim('"');
						}
						else if (!string.IsNullOrEmpty(contentDisposition.FileName))
						{
							text = contentDisposition.FileName.Trim('"');
						}
					}
					if (string.IsNullOrEmpty(text))
					{
						text = Path.GetFileName(new Uri(mod.DownloadLink).LocalPath);
					}
					string text2 = Path.GetExtension(text);
					if (string.IsNullOrEmpty(text2))
					{
						text2 = ".rar";
					}
					_currentDownloadFilePath = Path.Combine(_downloadPath, mod.Name + text2);
					using Stream contentStream = await response.Content.ReadAsStreamAsync();
					using FileStream fileStream = new FileStream(_currentDownloadFilePath, FileMode.Create, FileAccess.Write, FileShare.None, 8192, useAsync: true);
					byte[] buffer = new byte[8192];
					long totalRead = 0L;
					while (true)
					{
						int num;
						int bytesRead = (num = await contentStream.ReadAsync(buffer, 0, buffer.Length, _downloadCancellationTokenSource.Token));
						if (num <= 0)
						{
							break;
						}
						await WaitWhilePausedAsync(_downloadCancellationTokenSource.Token);
						await fileStream.WriteAsync(buffer, 0, bytesRead, _downloadCancellationTokenSource.Token);
						totalRead += bytesRead;
						if (canReportProgress)
						{
							double num2 = (double)totalRead * 100.0 / (double)totalBytes;
							double num3 = (double)totalRead / 1024.0 / 1024.0;
							NotificationDetails.Text = $"{num3:F2} MB / {totalMB:F2} MB ({num2:F1}%)";
							DownloadProgressBar.Value = num2;
						}
					}
				}
				finally
				{
					((IDisposable)response)?.Dispose();
				}
			}
			finally
			{
				((IDisposable)httpClient)?.Dispose();
			}
			if (await HttpClientHelper.UpdateDownloadsAsync(mod.Id))
			{
				NotificationTitle.Text = "Mod '" + mod.Name + "' is downloaded!";
			}
			NotificationDetails.Text = "Downloaded at: " + _downloadPath;
			_currentlyDownloadingMod.LocalFilePath = _currentDownloadFilePath;
			_currentlyDownloadingMod.IsDownloaded = true;
			List<string> list = Settings.Default.DownloadedMods.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
			if (!list.Contains(mod.ModId.ToString()))
			{
				list.Add(mod.ModId.ToString());
				Settings.Default.DownloadedMods = string.Join(",", list);
				Settings.Default.Save();
			}
			CollectionViewSource.GetDefaultView(ModsListBox.ItemsSource).Refresh();
			await Task.Delay(3000);
		}
		catch (OperationCanceledException)
		{
			if (!string.IsNullOrEmpty(_currentDownloadFilePath) && File.Exists(_currentDownloadFilePath))
			{
				File.Delete(_currentDownloadFilePath);
			}
		}
		catch (Exception ex2)
		{
			string text3 = ex2.Message + ((ex2.InnerException != null) ? ("\nInner: " + ex2.InnerException.Message) : "");
			System.Windows.MessageBox.Show("Error downloading mod:\n" + text3);
		}
		finally
		{
			NotificationPanel.Visibility = Visibility.Collapsed;
			_downloadCancellationTokenSource = null;
			_currentlyDownloadingMod = null;
			_currentDownloadFilePath = null;
			PauseButton.IsEnabled = false;
			ContinueButton.IsEnabled = false;
		}
	}

	private void CancelButton_Click(object sender, RoutedEventArgs e)
	{
		_downloadCancellationTokenSource?.Cancel();
	}

	private void PauseButton_Click(object sender, RoutedEventArgs e)
	{
		_pauseDownloadEvent.Reset();
		PauseButton.IsEnabled = false;
		ContinueButton.IsEnabled = true;
	}

	private void ContinueButton_Click(object sender, RoutedEventArgs e)
	{
		_pauseDownloadEvent.Set();
		PauseButton.IsEnabled = true;
		ContinueButton.IsEnabled = false;
	}

	private void DownloadPathButton_Click(object sender, RoutedEventArgs e)
	{
		using FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
		folderBrowserDialog.Description = "Choose a location to download mods.";
		folderBrowserDialog.ShowNewFolderButton = true;
		if (folderBrowserDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
		{
			_downloadPath = folderBrowserDialog.SelectedPath;
			Settings.Default.DownloadPath = _downloadPath;
			Settings.Default.Save();
			System.Windows.MessageBox.Show("Download location set to:\n" + _downloadPath, "Download Path", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
	}

	private async Task WaitWhilePausedAsync(CancellationToken cancellationToken)
	{
		while (!_pauseDownloadEvent.IsSet)
		{
			await Task.Delay(100, cancellationToken);
		}
	}

	private void FavoriteButton_Loaded(object sender, RoutedEventArgs e)
	{
		if (sender is System.Windows.Controls.Button { Tag: Mod tag } button)
		{
			string favorites = Settings.Default.Favorites;
			bool flag = !string.IsNullOrEmpty(favorites) && favorites.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries).Contains(tag.ModId.ToString());
			button.Content = (flag ? "★" : "☆");
			button.Foreground = (flag ? Brushes.Gold : Brushes.Gray);
		}
	}

	private void FavoriteButton_Click(object sender, RoutedEventArgs e)
	{
		if (sender is System.Windows.Controls.Button { Tag: Mod tag } button)
		{
			string favorites = Settings.Default.Favorites;
			List<string> list = new List<string>();
			if (!string.IsNullOrEmpty(favorites))
			{
				list = favorites.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
			}
			string item = tag.ModId.ToString();
			if (list.Contains(item))
			{
				list.Remove(item);
				button.Content = "☆";
				button.Foreground = Brushes.Gray;
			}
			else
			{
				list.Add(item);
				button.Content = "★";
				button.Foreground = Brushes.Gold;
			}
			Settings.Default.Favorites = string.Join(",", list);
			Settings.Default.Save();
		}
	}

	private void ReportButton_Click(object sender, RoutedEventArgs e)
	{
		if (sender is System.Windows.Controls.Button { Tag: Mod tag })
		{
			string username = Settings.Default.Username;
			ReportFunctions.ShowReportDialog(tag, username);
		}
	}

	private void FiltersButton_Click(object sender, RoutedEventArgs e)
	{
		FiltersPopup.IsOpen = true;
	}

	private async void ApplyFiltersButton_Click(object sender, RoutedEventArgs e)
	{
		string text = (CategoryComboBox_Filter.SelectedItem as ComboBoxItem)?.Content.ToString();
		if (text == "Show All")
		{
			text = null;
		}
		string text2 = (VIPFreeComboBox_Filter.SelectedItem as ComboBoxItem)?.Content.ToString();
		int? vipOnly = null;
		if (text2 == "VIP")
		{
			vipOnly = 1;
		}
		else if (text2 == "Free")
		{
			vipOnly = 0;
		}
		string sortBy = "newest";
		switch ((SortComboBox_Filter.SelectedItem as ComboBoxItem)?.Content.ToString())
		{
		case "Most Popular":
			sortBy = "downloads";
			break;
		case "Oldest First":
			sortBy = "oldest";
			break;
		case "Newest First":
			sortBy = "newest";
			break;
		}
		string text3 = (VersionComboBox_Filter.SelectedItem as ComboBoxItem)?.Content.ToString();
		if (string.IsNullOrEmpty(text3))
		{
			text3 = "All";
		}
		FiltersPopup.IsOpen = false;
		await LoadModsWithFilters(text, vipOnly, sortBy, text3);
	}

	private void CloseFiltersPopup_Click(object sender, RoutedEventArgs e)
	{
		FiltersPopup.IsOpen = false;
	}

	private void ResetFiltersButton_Click(object sender, RoutedEventArgs e)
	{
		CategoryComboBox_Filter.SelectedIndex = 0;
		VIPFreeComboBox_Filter.SelectedIndex = 0;
		VersionComboBox_Filter.SelectedIndex = 0;
		SortComboBox_Filter.SelectedIndex = 0;
		Overlay.Visibility = Visibility.Collapsed;
	}

	[DllImport("dwmapi.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int attributeValue, int attributeSize);

	public MainWindow()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Expected O, but got Unknown
		if (!Previlegije.IsRunningAsAdmin())
		{
			System.Windows.MessageBox.Show("The application does not have administrator privileges!\n\nIf the files are not updated or other problems occur, first try to run the application as an administrator. If you have problems again, ask for help on Discord!", "Moler - V2.0.9.4", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			Previlegije.RestartAsAdmin();
			return;
		}
		ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;
		InitializeComponent();
		EnableDarkModeTitleBar();
		_discordPlay.Initialize();
		InitializeApp();
		LoadUserSettings();
		base.Icon = new BitmapImage(new Uri("pack://application:,,,/images/logoikona.ico"));
		ShortcutHelper.CreateShortcutIfNeeded();
		if (!string.IsNullOrEmpty(Settings.Default.DownloadPath))
		{
			_downloadPath = Settings.Default.DownloadPath;
		}
		CheckOverlayMessage();
		ConnectToServer();
		_refreshTimer = new System.Timers.Timer(5000.0);
		_refreshTimer.Elapsed += async delegate
		{
			await UpdateOnlineCount();
			await CheckOverlayMessage();
		};
		_refreshTimer.Start();
		LoadModsAsync();
		LoadDownloadedStateAsync();
	}

	private async Task LoadDownloadedStateAsync()
	{
		await LoadModsAsync();
		List<string> list = Settings.Default.DownloadedMods.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
		foreach (Mod item in ModsListBox.Items.Cast<Mod>())
		{
			if (list.Contains(item.ModId.ToString()))
			{
				item.IsDownloaded = true;
			}
		}
		CollectionViewSource.GetDefaultView(ModsListBox.ItemsSource).Refresh();
	}

	private void UninstallMod_Click(object sender, RoutedEventArgs e)
	{
		if (!(sender is System.Windows.Controls.Button { Tag: Mod tag }))
		{
			return;
		}
		string[] files = Directory.GetFiles(_downloadPath, tag.Name + ".*");
		foreach (string path in files)
		{
			try
			{
				File.Delete(path);
			}
			catch (Exception ex)
			{
				System.Windows.MessageBox.Show("Error uninstalling '" + tag.Name + "': " + ex.Message, "Uninstall Error", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}
		tag.IsDownloaded = false;
		List<string> list = Settings.Default.DownloadedMods.Split(new char[1] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
		if (list.Contains(tag.ModId.ToString()))
		{
			list.Remove(tag.ModId.ToString());
			Settings.Default.DownloadedMods = string.Join(",", list);
			Settings.Default.Save();
		}
		CollectionViewSource.GetDefaultView(ModsListBox.ItemsSource).Refresh();
	}

	protected override void OnClosing(CancelEventArgs e)
	{
		_discordPlay.Shutdown();
		base.OnClosing(e);
	}

	private async void InitializeApp()
	{
		await Task.Run(() => HttpListenerService.StartListener());
	}

	private void Window_Loaded(object sender, RoutedEventArgs e)
	{
		EnableDarkModeTitleBar();
		if (BtnLogin.Content.ToString() == "Logout")
		{
			LoadModsAsync();
			CheckBanStatusIfLoggedIn();
		}
	}

	private void EnableDarkModeTitleBar()
	{
		IntPtr handle = new WindowInteropHelper(this).Handle;
		int attributeValue = 1;
		DwmSetWindowAttribute(handle, 20, ref attributeValue, 4);
	}

	private void MinimizeWindow(object sender, RoutedEventArgs e)
	{
		Storyboard storyboard = new Storyboard();
		DoubleAnimation doubleAnimation = new DoubleAnimation(1.0, 0.0, TimeSpan.FromMilliseconds(300.0));
		Storyboard.SetTarget(doubleAnimation, this);
		Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath("Opacity"));
		storyboard.Children.Add(doubleAnimation);
		storyboard.Completed += delegate
		{
			base.WindowState = WindowState.Minimized;
			base.Opacity = 1.0;
		};
		storyboard.Begin();
	}

	private void Window_StateChanged(object sender, EventArgs e)
	{
	}

	private void CloseWindow(object sender, RoutedEventArgs e)
	{
	}

	private void Window_Activated(object sender, EventArgs e)
	{
		if (base.WindowState == WindowState.Minimized)
		{
			base.WindowState = WindowState.Normal;
		}
	}

	private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
	{
		if (e.ChangedButton == MouseButton.Left)
		{
			DragMove();
		}
	}

	private async void BtnLogin_Click(object sender, RoutedEventArgs e)
	{
		if (BtnLogin.Content.ToString() == "Logout")
		{
			DiscordName.Text = "Not Logged In";
			BtnLogin.Content = "Login with Discord";
			Overlay.Visibility = Visibility.Visible;
			DisableUI();
			SaveUserSettings();
			ModsListBox.ItemsSource = null;
			return;
		}
		string text = "1369745511883477084";
		string stringToEscape = "http://localhost:4002/auth/discord/callback";
		string[] value = new string[3] { "identify", "guilds", "guilds.members.read" };
		string text2 = Uri.EscapeDataString(string.Join(" ", value));
		Process.Start(new ProcessStartInfo("https://discord.com/oauth2/authorize?client_id=" + text + "&redirect_uri=" + Uri.EscapeDataString(stringToEscape) + "&response_type=code&scope=" + text2)
		{
			UseShellExecute = true
		});
	}

	private void DisableUI()
	{
	}

	public void EnableUI()
	{
	}

	private void LoadUserSettings()
	{
		Settings settings = Settings.Default;
		if (settings.IsLoggedIn)
		{
			DiscordName.Text = settings.Username;
			BtnLogin.Content = "Logout";
			Overlay.Visibility = Visibility.Hidden;
			EnableUI();
		}
		else
		{
			DiscordName.Text = "Not Logged In";
			BtnLogin.Content = "Login with Discord";
			Overlay.Visibility = Visibility.Visible;
			DisableUI();
		}
	}

	private void SaveUserSettings()
	{
		Settings settings = Settings.Default;
		settings.IsLoggedIn = BtnLogin.Content.ToString() == "Logout";
		settings.Username = DiscordName.Text;
		settings.DownloadPath = _downloadPath;
		settings.Save();
	}

	private async void ConnectToServer()
	{
		try
		{
			await _httpClient.PostAsync("https://molerapi.moler.cloud//users/connectt", (HttpContent)null);
		}
		catch (Exception ex)
		{
			Console.WriteLine("Greška pri spajanju na server: " + ex.Message);
		}
	}

	private async void InfoButton_Click(object sender, RoutedEventArgs e)
	{
		ShowApiOverlay("If you see this text check out discord for more informations...");
		try
		{
			HttpResponseMessage val = await _httpClient.GetAsync("https://molerapi.moler.cloud//info");
			if (val.IsSuccessStatusCode)
			{
				string obj = await val.Content.ReadAsStringAsync();
				InfoPopupText.Inlines.Clear();
				string[] array = obj.Split('\n');
				foreach (string text in array)
				{
					if (Uri.IsWellFormedUriString(text.Trim(), UriKind.Absolute))
					{
						Hyperlink hyperlink = new Hyperlink(new Run(text.Trim()))
						{
							NavigateUri = new Uri(text.Trim())
						};
						hyperlink.RequestNavigate += Hyperlink_RequestNavigate;
						InfoPopupText.Inlines.Add(hyperlink);
					}
					else
					{
						InfoPopupText.Inlines.Add(new Run(text));
					}
					InfoPopupText.Inlines.Add(new LineBreak());
				}
			}
			else
			{
				InfoPopupText.Text = "Nije moguće dohvatiti informaciju sa servera.";
			}
		}
		catch (Exception ex)
		{
			InfoPopupText.Text = "Greška pri dohvaćanju: " + ex.Message;
		}
		finally
		{
			HideApiOverlay();
		}
		InfoPopup.IsOpen = true;
	}

	private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
	{
		Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri)
		{
			UseShellExecute = true
		});
		e.Handled = true;
	}

	private void InfoPopupClose_Click(object sender, RoutedEventArgs e)
	{
		InfoPopup.IsOpen = false;
	}

	private async Task UpdateOnlineCount()
	{
		try
		{
			HttpResponseMessage val = await _httpClient.GetAsync("https://molerapi.moler.cloud//users/onlinee");
			if (val.IsSuccessStatusCode)
			{
				OnlineResponse onlineData = JsonConvert.DeserializeObject<OnlineResponse>(await val.Content.ReadAsStringAsync());
				base.Dispatcher.Invoke(delegate
				{
					OnlineCountTextBlock.Text = $"Online: {onlineData.online}";
				});
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine("Greška pri dohvaćanju online broja: " + ex.Message);
		}
	}

	private async Task CheckOverlayMessage()
	{
		try
		{
			HttpResponseMessage val = await _httpClient.GetAsync("https://molerapi.moler.cloud//api/overlay-message1");
			if (val.IsSuccessStatusCode)
			{
				OverlayMessageResponse overlayMessageResponse = JsonConvert.DeserializeObject<OverlayMessageResponse>(await val.Content.ReadAsStringAsync());
				if (overlayMessageResponse.show)
				{
					ShowApiOverlay(overlayMessageResponse.message);
				}
				else
				{
					HideApiOverlay();
				}
			}
		}
		catch
		{
		}
	}

	private async Task DisconnectFromServer()
	{
		try
		{
			await _httpClient.PostAsync("https://molerapi.moler.cloud//users/disconnectt", (HttpContent)null);
		}
		catch (Exception ex)
		{
			Console.WriteLine("Greška pri odspajanju od servera: " + ex.Message);
		}
	}

	protected override async void OnClosed(EventArgs e)
	{
		_refreshTimer.Stop();
		await DisconnectFromServer();
		base.OnClosed(e);
	}

	private void ModsScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
	{
		JumpToTopButton.Visibility = ((!(e.VerticalOffset > 0.0)) ? Visibility.Collapsed : Visibility.Visible);
	}

	private void JumpToTopButton_Click(object sender, RoutedEventArgs e)
	{
		ModsScrollViewer.SmoothScrollTo(0.0, TimeSpan.FromMilliseconds(300.0));
	}

	private void OnBanExitClick(object sender, RoutedEventArgs e)
	{
		System.Windows.Application.Current.Shutdown();
	}

	private void OpenDownloadFolderButton_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = _downloadPath,
				UseShellExecute = true,
				Verb = "open"
			});
		}
		catch (Exception ex)
		{
			System.Windows.MessageBox.Show("Cannot open:\n" + ex.Message, "Greška", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void CategoryComboBox_Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		ComboBoxItem comboBoxItem = (ComboBoxItem)CategoryComboBox_Filter.SelectedItem;
		if (comboBoxItem.Content.ToString() == "Show All")
		{
			ShowAllCategories();
		}
		else
		{
			FilterModsByCategory(comboBoxItem.Content.ToString());
		}
	}

	private void ShowAllCategories()
	{
	}

	private void FilterModsByCategory(string category)
	{
	}

	private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
	{
		_searchQuery = SearchTextBox.Text.Trim();
		LoadModsAsync();
	}

	private async Task LoadModsAsync()
	{
		try
		{
			List<Mod> list = await HttpClientHelper.GetModsAsync();
			List<Mod> filtered = (string.IsNullOrEmpty(_searchQuery) ? list : list.Where((Mod m) => m.Name.IndexOf(_searchQuery, StringComparison.OrdinalIgnoreCase) >= 0).ToList());
			base.Dispatcher.Invoke(() => ModsListBox.ItemsSource = filtered);
		}
		catch (Exception ex)
		{
			Console.WriteLine("Greška kod učitavanja modova: " + ex.Message);
		}
	}

	private void ShowApiOverlay(string message)
	{
		base.Dispatcher.Invoke(delegate
		{
			ApiOverlayMessage.Inlines.Clear();
			string[] array = message.Split('\n');
			foreach (string text in array)
			{
				if (Uri.IsWellFormedUriString(text.Trim(), UriKind.Absolute))
				{
					Hyperlink hyperlink = new Hyperlink(new Run(text.Trim()))
					{
						NavigateUri = new Uri(text.Trim())
					};
					hyperlink.RequestNavigate += Hyperlink_RequestNavigate;
					ApiOverlayMessage.Inlines.Add(hyperlink);
				}
				else
				{
					ApiOverlayMessage.Inlines.Add(new Run(text));
				}
				ApiOverlayMessage.Inlines.Add(new LineBreak());
			}
			ApiOverlay.Visibility = Visibility.Visible;
		});
	}

	private void HideApiOverlay()
	{
		base.Dispatcher.Invoke(delegate
		{
			ApiOverlay.Visibility = Visibility.Collapsed;
			return Visibility.Collapsed;
		});
	}
}
