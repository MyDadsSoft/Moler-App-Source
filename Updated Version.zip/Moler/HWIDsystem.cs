using System.Management;
using System.Security.Cryptography;
using System.Text;

namespace Moler;

public static class HWIDsystem
{
	public static string GetCpuId()
	{
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
			using ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = managementObjectSearcher.Get().GetEnumerator();
			object obj2;
			if (managementObjectEnumerator.MoveNext())
			{
				object obj = managementObjectEnumerator.Current["ProcessorId"];
				if (obj == null)
				{
					obj2 = null;
				}
				else
				{
					obj2 = obj.ToString();
					if (obj2 != null)
					{
						goto IL_0044;
					}
				}
				obj2 = "unknown";
				goto IL_0044;
			}
			goto end_IL_0017;
			IL_0044:
			return (string)obj2;
			end_IL_0017:;
		}
		catch
		{
		}
		return "unknown";
	}

	public static string GetMotherboardId()
	{
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard");
			using ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = managementObjectSearcher.Get().GetEnumerator();
			object obj2;
			if (managementObjectEnumerator.MoveNext())
			{
				object obj = managementObjectEnumerator.Current["SerialNumber"];
				if (obj == null)
				{
					obj2 = null;
				}
				else
				{
					obj2 = obj.ToString();
					if (obj2 != null)
					{
						goto IL_0044;
					}
				}
				obj2 = "unknown";
				goto IL_0044;
			}
			goto end_IL_0017;
			IL_0044:
			return (string)obj2;
			end_IL_0017:;
		}
		catch
		{
		}
		return "unknown";
	}

	public static string GetGpuId()
	{
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT PNPDeviceID FROM Win32_VideoController");
			using ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = managementObjectSearcher.Get().GetEnumerator();
			object obj2;
			if (managementObjectEnumerator.MoveNext())
			{
				object obj = managementObjectEnumerator.Current["PNPDeviceID"];
				if (obj == null)
				{
					obj2 = null;
				}
				else
				{
					obj2 = obj.ToString();
					if (obj2 != null)
					{
						goto IL_0044;
					}
				}
				obj2 = "unknown";
				goto IL_0044;
			}
			goto end_IL_0017;
			IL_0044:
			return (string)obj2;
			end_IL_0017:;
		}
		catch
		{
		}
		return "unknown";
	}

	public static string GetHWID()
	{
		string s = GetCpuId() + GetMotherboardId() + GetGpuId();
		using SHA256 sHA = SHA256.Create();
		byte[] array = sHA.ComputeHash(Encoding.UTF8.GetBytes(s));
		StringBuilder stringBuilder = new StringBuilder();
		byte[] array2 = array;
		foreach (byte b in array2)
		{
			stringBuilder.Append(b.ToString("x2"));
		}
		return stringBuilder.ToString();
	}
}
