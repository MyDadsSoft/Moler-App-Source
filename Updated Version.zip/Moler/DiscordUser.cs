namespace Moler;

public class DiscordUser
{
	public string id { get; set; }

	public string username { get; set; }

	public string discriminator { get; set; }

	public string avatar { get; set; }
}
