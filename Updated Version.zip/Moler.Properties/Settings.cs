using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Moler.Properties;

[CompilerGenerated]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "17.13.0.0")]
internal sealed class Settings : ApplicationSettingsBase
{
	private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

	public static Settings Default => defaultInstance;

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("False")]
	public bool IsLoggedIn
	{
		get
		{
			return (bool)this["IsLoggedIn"];
		}
		set
		{
			this["IsLoggedIn"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("Not Logged In")]
	public string Username
	{
		get
		{
			return (string)this["Username"];
		}
		set
		{
			this["Username"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("-1")]
	public int CategoryIndex
	{
		get
		{
			return (int)this["CategoryIndex"];
		}
		set
		{
			this["CategoryIndex"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("-1")]
	public int VIPFreeIndex
	{
		get
		{
			return (int)this["VIPFreeIndex"];
		}
		set
		{
			this["VIPFreeIndex"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("-1")]
	public int SortDateIndex
	{
		get
		{
			return (int)this["SortDateIndex"];
		}
		set
		{
			this["SortDateIndex"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string DownloadPath
	{
		get
		{
			return (string)this["DownloadPath"];
		}
		set
		{
			this["DownloadPath"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string Favorites
	{
		get
		{
			return (string)this["Favorites"];
		}
		set
		{
			this["Favorites"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("All")]
	public string VersionFilter
	{
		get
		{
			return (string)this["VersionFilter"];
		}
		set
		{
			this["VersionFilter"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string UserId
	{
		get
		{
			return (string)this["UserId"];
		}
		set
		{
			this["UserId"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string DiscordId
	{
		get
		{
			return (string)this["DiscordId"];
		}
		set
		{
			this["DiscordId"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string DownloadedMods
	{
		get
		{
			return (string)this["DownloadedMods"];
		}
		set
		{
			this["DownloadedMods"] = value;
		}
	}
}
