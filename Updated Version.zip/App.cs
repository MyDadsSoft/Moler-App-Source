using System.Windows;
using Dark.Net;

public class App : Application
{
	protected override void OnStartup(StartupEventArgs e)
	{
		base.OnStartup(e);
		DarkNet.Instance.SetCurrentProcessTheme(Theme.Auto);
	}
}
